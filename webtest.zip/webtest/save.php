<?php
    require_once "connection.php";
    if(isset($_POST['submit'])){

        $name = $_POST['name'];
        $class = $_POST['class'];
        $rollno = $_POST['rollno'];
        $dob = $_POST['dob'];

        if($name != "" && $class != "" && $rollno != "" ){
            $sql = "INSERT INTO student_details (`name`, `class`, `rollno`,`dob`) VALUES ('$name', '$class', $rollno, $dob)";
            if (mysqli_query($con, $sql)) {
                header("location: student.php");
            } else {
                 echo "Something went wrong. Please try again later.";
            }
        }else{
            echo "Name, Class and Marks cannot be empty!";
        }
    }
?>