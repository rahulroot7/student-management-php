<?php
   session_start();
   unset($_SESSION["email"]);
   unset($_SESSION["password"]);
   
   echo 'Logout Successfull';
   header("Location: index.php"); 
?>