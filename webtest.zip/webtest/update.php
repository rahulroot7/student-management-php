<?php
    require_once "connection.php";
    if(isset($_POST['submit'])){
        $id = $_POST['id'];
        $name = $_POST['name'];
        $class = $_POST['class'];
        $rollno = $_POST['rollno'];
        $dob = $_POST['dob'];

        if($name != "" && $class != "" && $rollno != "" ){
            $update="update student_details set name='".$name."',class='".$class."', rollno='".$rollno."',dob='".$dob."' where id='".$id."'";
            if (mysqli_query($con, $update)) {
                header("location: student.php");
            } else {
                 echo "Something went wrong. Please try again later.";
            }
        }else{
            echo "Name, Class and Marks cannot be empty!";
        }
    }
?>