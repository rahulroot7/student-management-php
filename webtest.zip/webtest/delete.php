<?php
    require_once "connection.php";
    $id = $_GET["id"];
    $query = "DELETE FROM student_details WHERE id = '$id'";
    if (mysqli_query($con, $query)) {
        header("location: student.php");
    } else {
         echo "Something went wrong. Please try again later.";
    }
?>